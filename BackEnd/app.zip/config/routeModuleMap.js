/**
 * routeModuleMap.js
 *
 * Mapeo central de rutas del backend a su módulo/transacción correspondiente
 * según el catálogo global (public.module_catalog + public.module_transactions).
 *
 * Usado por el middleware `requireModule` para validar (en modo log-only
 * durante la fase 3) que el usuario tenga acceso al módulo de la compañía
 * antes de ejecutar el controller.
 *
 * Formato: { 'METHOD /path': { module: 'code', transaction: 'code' } }
 * - module:      código en public.module_catalog
 * - transaction: código en public.module_transactions (opcional)
 *
 * Las rutas usan el path base después de /api/... y aceptan comodines
 * básicos mediante path-to-regex style: `:id`, `:userId`, etc.
 *
 * Si una ruta NO está en el mapa, el middleware no valida (default-permit).
 */

const ROUTE_MODULE_MAP = {
    // ── Catálogo y menú (accesibles para todo user autenticado) ──
    // No se mapean → default-permit

    // ── Configuration: Companies ──
    'GET    /companies':                   { module: 'configuration', transaction: 'companies' },
    'POST   /companies':                   { module: 'configuration', transaction: 'companies' },
    'GET    /companies/:id':               { module: 'configuration', transaction: 'companies' },
    'PUT    /companies/:id':               { module: 'configuration', transaction: 'companies' },
    'DELETE /companies/:id':               { module: 'configuration', transaction: 'companies' },
    'GET    /companies/:id/config':        { module: 'configuration', transaction: 'companies' },
    'PUT    /companies/:id/config':        { module: 'configuration', transaction: 'companies' },
    'GET    /companies/:id/roles':         { module: 'configuration', transaction: 'companies' },

    // ── Configuration: Users ──
    'GET    /companies/:id/users':                           { module: 'configuration', transaction: 'users' },
    'POST   /companies/:id/users':                           { module: 'configuration', transaction: 'users' },
    'PUT    /companies/:id/users/:userId':                   { module: 'configuration', transaction: 'users' },
    'PATCH  /companies/:id/users/:userId/status':            { module: 'configuration', transaction: 'users' },
    'POST   /companies/:id/users/:userId/profiles':          { module: 'configuration', transaction: 'users' },
    'DELETE /companies/:id/users/:userId/profiles/:profileId': { module: 'configuration', transaction: 'users' },
    'DELETE /companies/:id/users/:userId':                   { module: 'configuration', transaction: 'users' },
    'GET    /users':                                         { module: 'configuration', transaction: 'users' },
    'POST   /users/avatar':                                  { module: 'configuration', transaction: 'users' },

    // ── Configuration: Profiles (company-scoped, super_admin) ──
    'GET    /companies/:id/profiles':                              { module: 'configuration', transaction: 'profiles' },
    'POST   /companies/:id/profiles':                             { module: 'configuration', transaction: 'profiles' },
    'PUT    /companies/:id/profiles/:profileId':                  { module: 'configuration', transaction: 'profiles' },
    'DELETE /companies/:id/profiles/:profileId':                  { module: 'configuration', transaction: 'profiles' },
    'GET    /companies/:id/profiles/:profileId/permissions-full': { module: 'configuration', transaction: 'profiles' },
    'PUT    /companies/:id/profiles/:profileId/permissions-full': { module: 'configuration', transaction: 'profiles' },

    // ── Configuration: Profiles ──
    'GET    /profiles':                    { module: 'configuration', transaction: 'profiles' },
    'GET    /profiles/:id':                { module: 'configuration', transaction: 'profiles' },
    'GET    /profiles/:id/permissions':         { module: 'configuration', transaction: 'profiles' },
    'PUT    /profiles/:id/permissions':         { module: 'configuration', transaction: 'profiles' },
    'GET    /profiles/:id/permissions-full':    { module: 'configuration', transaction: 'profiles' },
    'PUT    /profiles/:id/permissions-full':    { module: 'configuration', transaction: 'profiles' },
    'POST   /profiles':                    { module: 'configuration', transaction: 'profiles' },
    'PUT    /profiles/:id':                { module: 'configuration', transaction: 'profiles' },
    'DELETE /profiles/:id':                { module: 'configuration', transaction: 'profiles' },

    // ── Configuration: Modules (catálogo y tenant legacy) ──
    'GET    /modules':                     { module: 'configuration', transaction: 'modules' },
    'GET    /modules/:id':                 { module: 'configuration', transaction: 'modules' },
    'POST   /modules':                     { module: 'configuration', transaction: 'modules' },
    'PUT    /modules/:id':                 { module: 'configuration', transaction: 'modules' },
    'PATCH  /modules/:id/status':          { module: 'configuration', transaction: 'modules' },
    'DELETE /modules/:id':                 { module: 'configuration', transaction: 'modules' },
    'GET    /catalog/modules':             { module: 'configuration', transaction: 'modules' },
    'GET    /catalog/modules/:id':         { module: 'configuration', transaction: 'modules' },
    'PUT    /catalog/modules/:id':         { module: 'configuration', transaction: 'modules' },
    'GET    /catalog/transactions':        { module: 'configuration', transaction: 'modules' },
    'PUT    /catalog/transactions/:id':    { module: 'configuration', transaction: 'modules' },
    'GET    /companies/:id/modules':       { module: 'configuration', transaction: 'modules' },
    'PUT    /companies/:id/modules/:moduleCode': { module: 'configuration', transaction: 'modules' },

    // ── Configuration: Reports ──
    'GET    /stats':                       { module: 'configuration', transaction: 'reports' },

    // ── Configuration: Commercial ──
    'PATCH  /companies/:id/commercial-status':               { module: 'configuration', transaction: 'commercial' },
    'GET    /companies/:id/agreements':                      { module: 'configuration', transaction: 'commercial' },
    'POST   /companies/:id/agreements':                      { module: 'configuration', transaction: 'commercial' },
    'PUT    /companies/:id/agreements/:aId':                 { module: 'configuration', transaction: 'commercial' },
    'POST   /companies/:id/agreements/:aId/generate-invoice': { module: 'configuration', transaction: 'commercial' },
    'GET    /companies/:id/invoices':                        { module: 'configuration', transaction: 'commercial' },
    'POST   /companies/:id/invoices':                        { module: 'configuration', transaction: 'commercial' },
    'PUT    /companies/:id/invoices/:iId':                   { module: 'configuration', transaction: 'commercial' },
    'POST   /companies/:id/invoices/:iId/payment':           { module: 'configuration', transaction: 'commercial' },
    'GET    /companies/:id/payments':                        { module: 'configuration', transaction: 'commercial' },

    // ── Configuration: Subscriptions ──
    'GET    /subscriptions/company/:companyId':              { module: 'configuration', transaction: 'subscriptions' },
    'GET    /subscriptions/company/:companyId/payments':     { module: 'configuration', transaction: 'subscriptions' },
    'POST   /subscriptions':                                 { module: 'configuration', transaction: 'subscriptions' },
    'PUT    /subscriptions/:id':                             { module: 'configuration', transaction: 'subscriptions' },
    'POST   /subscriptions/:id/payment':                     { module: 'configuration', transaction: 'subscriptions' },

    // ── Configuration: Requests (Solicitudes) ──
    'GET    /solicitudes':                 { module: 'configuration', transaction: 'requests' },
    'PUT    /solicitudes/:id':             { module: 'configuration', transaction: 'requests' },
    // POST /solicitudes/public is public — no mapeo

    // ── Garage Operations: Dashboard ──
    'GET    /garage/dashboard':            { module: 'garage_operations', transaction: 'garage_dashboard' },

    // ── Garage Operations: Catálogos ──
    'GET    /garage/catalogs/:type':            { module: 'garage_operations', transaction: 'garage_dashboard' },
    'POST   /garage/catalogs/:type':            { module: 'garage_operations', transaction: 'garage_dashboard' },
    'PUT    /garage/catalogs/:type/:id':        { module: 'garage_operations', transaction: 'garage_dashboard' },
    'PATCH  /garage/catalogs/:type/:id/status': { module: 'garage_operations', transaction: 'garage_dashboard' },

    // ── Garage Operations: Clientes ──
    'GET    /garage/customers':                  { module: 'garage_operations', transaction: 'garage_customers' },
    'POST   /garage/customers':                  { module: 'garage_operations', transaction: 'garage_customers' },
    'GET    /garage/customers/:id':              { module: 'garage_operations', transaction: 'garage_customers' },
    'PUT    /garage/customers/:id':              { module: 'garage_operations', transaction: 'garage_customers' },
    'PATCH  /garage/customers/:id/status':       { module: 'garage_operations', transaction: 'garage_customers' },
    'POST   /garage/customers/:id/photo':        { module: 'garage_operations', transaction: 'garage_customers' },
    'DELETE /garage/customers/:id/photo':        { module: 'garage_operations', transaction: 'garage_customers' },

    // ── Garage Operations: Vehículos ──
    'GET    /garage/vehicles':                           { module: 'garage_operations', transaction: 'garage_vehicles' },
    'POST   /garage/vehicles':                           { module: 'garage_operations', transaction: 'garage_vehicles' },
    'GET    /garage/vehicles/:id':                       { module: 'garage_operations', transaction: 'garage_vehicles' },
    'PUT    /garage/vehicles/:id':                       { module: 'garage_operations', transaction: 'garage_vehicles' },
    'PATCH  /garage/vehicles/:id/status':                { module: 'garage_operations', transaction: 'garage_vehicles' },
    'GET    /garage/vehicles/:id/history':               { module: 'garage_operations', transaction: 'garage_vehicle_history' },
    'GET    /garage/vehicles/:id/photos':                { module: 'garage_operations', transaction: 'garage_vehicles' },
    'POST   /garage/vehicles/:id/photos':                { module: 'garage_operations', transaction: 'garage_vehicles' },
    'DELETE /garage/vehicles/:id/photos/:photoId':       { module: 'garage_operations', transaction: 'garage_vehicles' },
    'GET    /garage/customers/:id/vehicles':             { module: 'garage_operations', transaction: 'garage_vehicles' },

    // ── Garage Operations: Empleados ──
    'GET    /garage/employees':              { module: 'garage_operations', transaction: 'garage_employees' },
    'POST   /garage/employees':              { module: 'garage_operations', transaction: 'garage_employees' },
    'GET    /garage/employees/:id':          { module: 'garage_operations', transaction: 'garage_employees' },
    'PUT    /garage/employees/:id':          { module: 'garage_operations', transaction: 'garage_employees' },
    'PATCH  /garage/employees/:id/status':   { module: 'garage_operations', transaction: 'garage_employees' },
    'POST   /garage/employees/:id/photo':    { module: 'garage_operations', transaction: 'garage_employees' },
    'DELETE /garage/employees/:id/photo':    { module: 'garage_operations', transaction: 'garage_employees' },

    // ── Garage Operations: Tarifas ──
    'GET    /garage/labor-rates':                          { module: 'garage_operations', transaction: 'garage_labor_rates' },
    'POST   /garage/labor-rates':                          { module: 'garage_operations', transaction: 'garage_labor_rates' },
    'GET    /garage/labor-rates/:id':                      { module: 'garage_operations', transaction: 'garage_labor_rates' },
    'PUT    /garage/labor-rates/:id':                      { module: 'garage_operations', transaction: 'garage_labor_rates' },
    'PATCH  /garage/labor-rates/:id/status':               { module: 'garage_operations', transaction: 'garage_labor_rates' },
    'GET    /garage/employees/:employeeId/labor-rates':    { module: 'garage_operations', transaction: 'garage_labor_rates' },

    // ── Garage Operations: Productos ──
    'GET    /garage/products':              { module: 'garage_operations', transaction: 'garage_products' },
    'POST   /garage/products':              { module: 'garage_operations', transaction: 'garage_products' },
    'GET    /garage/products/:id':          { module: 'garage_operations', transaction: 'garage_products' },
    'PUT    /garage/products/:id':          { module: 'garage_operations', transaction: 'garage_products' },
    'PATCH  /garage/products/:id/status':   { module: 'garage_operations', transaction: 'garage_products' },

    // ── Garage Operations: Servicios configurables ──
    'GET    /garage/service-templates':                            { module: 'garage_operations', transaction: 'garage_service_templates' },
    'POST   /garage/service-templates':                            { module: 'garage_operations', transaction: 'garage_service_templates' },
    'GET    /garage/service-templates/:id':                        { module: 'garage_operations', transaction: 'garage_service_templates' },
    'PUT    /garage/service-templates/:id':                        { module: 'garage_operations', transaction: 'garage_service_templates' },
    'PATCH  /garage/service-templates/:id/status':                 { module: 'garage_operations', transaction: 'garage_service_templates' },
    'POST   /garage/service-templates/:id/products':               { module: 'garage_operations', transaction: 'garage_service_templates' },
    'DELETE /garage/service-templates/:id/products/:productId':    { module: 'garage_operations', transaction: 'garage_service_templates' },

    // ── Garage Operations: Citas ──
    'GET    /garage/appointments':                               { module: 'garage_operations', transaction: 'garage_appointments' },
    'POST   /garage/appointments':                               { module: 'garage_operations', transaction: 'garage_appointments' },
    'GET    /garage/appointments/:id':                           { module: 'garage_operations', transaction: 'garage_appointments' },
    'PUT    /garage/appointments/:id':                           { module: 'garage_operations', transaction: 'garage_appointments' },
    'PATCH  /garage/appointments/:id/status':                    { module: 'garage_operations', transaction: 'garage_appointments' },
    'POST   /garage/appointments/:id/confirm':                   { module: 'garage_operations', transaction: 'garage_appointments' },
    'POST   /garage/appointments/:id/mark-arrived':              { module: 'garage_operations', transaction: 'garage_appointments' },
    'POST   /garage/appointments/:id/cancel':                    { module: 'garage_operations', transaction: 'garage_appointments' },
    'POST   /garage/appointments/:id/reschedule':                { module: 'garage_operations', transaction: 'garage_appointments' },
    'POST   /garage/appointments/:id/convert-to-work-order':     { module: 'garage_operations', transaction: 'garage_appointments' },

    // ── Garage Operations: Órdenes de trabajo ──
    'GET    /garage/work-orders':                                        { module: 'garage_operations', transaction: 'garage_work_orders' },
    'POST   /garage/work-orders':                                        { module: 'garage_operations', transaction: 'garage_work_orders' },
    'GET    /garage/work-orders/:id':                                    { module: 'garage_operations', transaction: 'garage_work_orders' },
    'PUT    /garage/work-orders/:id':                                    { module: 'garage_operations', transaction: 'garage_work_orders' },
    'PATCH  /garage/work-orders/:id/status':                             { module: 'garage_operations', transaction: 'garage_work_orders' },
    'PATCH  /garage/work-orders/:id/assign':                             { module: 'garage_operations', transaction: 'garage_work_orders' },
    'POST   /garage/work-orders/:id/recalculate':                        { module: 'garage_operations', transaction: 'garage_work_orders' },
    'POST   /garage/work-orders/:id/close':                              { module: 'garage_operations', transaction: 'garage_work_orders' },
    'POST   /garage/work-orders/:id/cancel':                             { module: 'garage_operations', transaction: 'garage_work_orders' },
    'GET    /garage/work-orders/:id/services':                           { module: 'garage_operations', transaction: 'garage_work_orders' },
    'POST   /garage/work-orders/:id/services':                           { module: 'garage_operations', transaction: 'garage_work_orders' },
    'GET    /garage/work-orders/:id/services/:serviceId':                { module: 'garage_operations', transaction: 'garage_work_orders' },
    'PUT    /garage/work-orders/:id/services/:serviceId':                { module: 'garage_operations', transaction: 'garage_work_orders' },
    'DELETE /garage/work-orders/:id/services/:serviceId':                { module: 'garage_operations', transaction: 'garage_work_orders' },
    'PATCH  /garage/work-orders/:id/services/:serviceId/status':         { module: 'garage_operations', transaction: 'garage_work_orders' },
    'POST   /garage/work-orders/:id/services/:serviceId/products':       { module: 'garage_operations', transaction: 'garage_work_orders' },
    'DELETE /garage/work-orders/:id/services/:serviceId/products/:productLineId': { module: 'garage_operations', transaction: 'garage_work_orders' },

    // ── Garage Operations: Fotos de orden ──
    'GET    /garage/work-orders/:id/photos':                { module: 'garage_operations', transaction: 'garage_work_orders' },
    'POST   /garage/work-orders/:id/photos':                { module: 'garage_operations', transaction: 'garage_work_orders' },
    'DELETE /garage/work-orders/:id/photos/:photoId':       { module: 'garage_operations', transaction: 'garage_work_orders' },

    // ── Garage Operations: Pagos de orden ──
    'GET    /garage/work-orders/:id/payments':              { module: 'garage_operations', transaction: 'garage_work_orders' },
    'POST   /garage/work-orders/:id/payments':              { module: 'garage_operations', transaction: 'garage_work_orders' },
    'DELETE /garage/work-orders/:id/payments/:paymentId':   { module: 'garage_operations', transaction: 'garage_work_orders' },
};

/**
 * Convierte un path con parámetros (ej: /companies/:id) en una regex.
 */
function pathToRegex(path) {
    const escaped = path
        .replace(/[-/\\^$*+?.()|[\]{}]/g, (c) => c === '/' ? '/' : `\\${c}`)
        .replace(/\\:(\w+)/g, '[^/]+');
    return new RegExp(`^${escaped}$`);
}

// Pre-compile regex para todas las rutas del mapa
const COMPILED = Object.entries(ROUTE_MODULE_MAP).map(([key, value]) => {
    const [method, path] = key.trim().split(/\s+/);
    return {
        method: method.toUpperCase(),
        regex:  pathToRegex(path),
        path,
        ...value
    };
});

/**
 * Resuelve módulo/transacción para una ruta + método.
 * Retorna null si la ruta no está mapeada (default-permit).
 */
function resolveRouteModule(method, path) {
    const m = method.toUpperCase();
    for (const entry of COMPILED) {
        if (entry.method === m && entry.regex.test(path)) {
            return { module: entry.module, transaction: entry.transaction };
        }
    }
    return null;
}

module.exports = {
    ROUTE_MODULE_MAP,
    resolveRouteModule
};
